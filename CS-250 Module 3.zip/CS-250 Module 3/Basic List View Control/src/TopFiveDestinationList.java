import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;


//Timothy Jayson
//SNHU CS-250
//Module 3 top 5 destination list

public class TopFiveDestinationList {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
            	TopDestinationListFrame topDestinationListFrame = new TopDestinationListFrame();
                topDestinationListFrame.setTitle("Top 5 Destination List");
                topDestinationListFrame.setVisible(true);
            }
        });
    }
}


class TopDestinationListFrame extends JFrame {
    private DefaultListModel listModel;

    public TopDestinationListFrame() {
        super("Top Five Destination List");

        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setSize(900, 750);

        listModel = new DefaultListModel();

        //Make updates to your top 5 list below. Import the new image files to resources directory.
        addDestinationNameAndPicture("1. Top Destination: Caribbean Beaches: Enjoy a beacutiful and relaxing vacation in one of our many Caribbean beach packages!", new ImageIcon(getClass().getResource("/resources/512px-Havelock_Island,_Mangrove_tree_on_the_beach,_Andaman_Islands.jpg")));
        // I added the destination name, description, and image to the above line of code.
        addDestinationNameAndPicture("2. 2nd Top Destination: Destination Cruises: Enjoy an exciting trip aboard a destination cruise ship in one of our many vacation packages!", new ImageIcon(getClass().getResource("/resources/512px-Cruise_ship_Le_Lyrial_off_Anvers_Island,_Antarctica_V-P.jpg")));
     // I added the destination name, description, and image to the above line of code.
        addDestinationNameAndPicture("3. 3rd Top Destination: Desert Getaway: Come and see the beauty of desert life on your next vacation in one of our many vacation packages !", new ImageIcon(getClass().getResource("/resources/512px-Acacia_in_Ein_Khadra_Desert_Oasis_00_(87).jpg")));
     // I added the destination name, description, and image to the above line of code.
        addDestinationNameAndPicture("4. 4th Top Destination: Grand Canyon: Come and see the majestic views of the Grand Canyon in one of our many vacation packages!", new ImageIcon(getClass().getResource("/resources/512px-Grand_Canyon_South_Rim_at_Sunset.jpg")));
     // I added the destination name, description, and image to the above line of code.
        addDestinationNameAndPicture("5. 5th Top Destination: Historical Italy! Come and see all of the beautiful historic sites of Italy in one of our vacation packages!", new ImageIcon(getClass().getResource("/resources/512px-Colosseo_2020.jpg")));
     // I added the destination name, description, and image to the above line of code.
        
        JList list = new JList(listModel);
        JScrollPane scrollPane = new JScrollPane(list);

        TextAndIconListCellRenderer renderer = new TextAndIconListCellRenderer(2);

        list.setCellRenderer(renderer);
        list.setBackground(Color.yellow); //This sets the background color of the UI to yellow.

        getContentPane().add(scrollPane, BorderLayout.CENTER);
    }

    private void addDestinationNameAndPicture(String text, Icon icon) {
        TextAndIcon tai = new TextAndIcon(text, icon);
        listModel.addElement(tai);
    }
}


class TextAndIcon {
    private String text;
    private Icon icon;

    public TextAndIcon(String text, Icon icon) {
        this.text = text;
        this.icon = icon;
    }

    public String getText() {
        return text;
    }

    public Icon getIcon() {
        return icon;
    }

    public void setText(String text) {
        this.text = text;
    }

    public void setIcon(Icon icon) {
        this.icon = icon;
    }
}


class TextAndIconListCellRenderer extends JLabel implements ListCellRenderer {
    private static final Border NO_FOCUS_BORDER = new EmptyBorder(1, 1, 1, 1);

    private Border insideBorder;

    public TextAndIconListCellRenderer() {
        this(0, 0, 0, 0);
    }

    public TextAndIconListCellRenderer(int padding) {
        this(padding, padding, padding, padding);
    }

    public TextAndIconListCellRenderer(int topPadding, int rightPadding, int bottomPadding, int leftPadding) {
        insideBorder = BorderFactory.createEmptyBorder(topPadding, leftPadding, bottomPadding, rightPadding);
        setOpaque(true);
    }

    public Component getListCellRendererComponent(JList list, Object value,
    int index, boolean isSelected, boolean hasFocus) {
        // The object from the combo box model MUST be a TextAndIcon.
        TextAndIcon tai = (TextAndIcon) value;

        // Sets text and icon on 'this' JLabel.
        setText(tai.getText());
        setIcon(tai.getIcon());

        if (isSelected) {
            setBackground(list.getSelectionBackground());
            setForeground(list.getSelectionForeground());
        } else {
            setBackground(list.getBackground());
            setForeground(list.getForeground());
        }

        Border outsideBorder;

        if (hasFocus) {
            outsideBorder = UIManager.getBorder("List.focusCellHighlightBorder");
        } else {
            outsideBorder = NO_FOCUS_BORDER;
        }

        setBorder(BorderFactory.createCompoundBorder(outsideBorder, insideBorder));
        setComponentOrientation(list.getComponentOrientation());
        setEnabled(list.isEnabled());
        setFont(list.getFont());

        return this;
    }

    // The following methods are overridden to be empty for performance
    // reasons. If you want to understand better why, please read:
    //
    // http://java.sun.com/javase/6/docs/api/javax/swing/DefaultListCellRenderer.html#override

    public void validate() {}
    public void invalidate() {}
    public void repaint() {}
    public void revalidate() {}
    public void repaint(long tm, int x, int y, int width, int height) {}
    public void repaint(Rectangle r) {}
}